export interface TrainerEntity {
    id: string;
    userId: string;
    specializationId: string;
}
