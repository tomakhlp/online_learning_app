export interface StudentEntity {
    id: string;
    userId: string;
    dateOfBirth: string | null;
    address: string | null;
}
