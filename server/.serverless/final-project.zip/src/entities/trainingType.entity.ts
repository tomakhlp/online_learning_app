export interface TrainingTypeEntity {
    id: string;
    trainingType: string;
}
