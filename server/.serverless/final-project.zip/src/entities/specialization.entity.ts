export interface SpecializationEntity {
    id: string;
    specialization: string;
}
