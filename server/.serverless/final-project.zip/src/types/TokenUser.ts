export interface TokenUser {
    sub: string;
    username: string;
}
