export class StudentDetailsResponseDto {
    id: string;
    userId: string;
    firstName: string;
    lastName: string;
    isActive: boolean;
}
