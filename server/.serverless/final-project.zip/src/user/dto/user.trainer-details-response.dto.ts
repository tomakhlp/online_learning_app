export class TrainerDetailsResponseDto {
    id: string;
    userId: string;
    firstName: string;
    lastName: string;
    specialization: string;
}
