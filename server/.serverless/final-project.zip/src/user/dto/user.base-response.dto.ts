export class BaseUserResponseDto {
    id: string;
    username: string;
    email: string;
    photo: string;
}
