export const TRAINING_TYPES = [
    { id: 'trainingType1', trainingType: 'webinar' },
    { id: 'trainingType2', trainingType: 'lecture' },
    { id: 'trainingType3', trainingType: 'workshop' },
];
