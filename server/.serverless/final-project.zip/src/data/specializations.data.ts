export const SPECIALIZATIONS = [
    { id: 'specialization1', specialization: 'java' },
    { id: 'specialization2', specialization: 'python' },
    { id: 'specialization3', specialization: 'c++' },
    { id: 'specialization4', specialization: 'typescript' },
    { id: 'specialization5', specialization: 'javascript' },
    { id: 'specialization6', specialization: 'go' },
    { id: 'specialization7', specialization: 'c#' },
    { id: 'specialization8', specialization: 'ruby' },
    { id: 'specialization9', specialization: 'kotlin' },
];
